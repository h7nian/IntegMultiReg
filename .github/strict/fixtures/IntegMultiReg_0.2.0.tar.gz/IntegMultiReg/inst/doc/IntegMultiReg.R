## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 4.2
)
set.seed(1)

## ----load---------------------------------------------------------------------
library(IntegMultiReg)
data("simIMR", package = "IntegMultiReg")
sapply(simIMR$platforms, dim)

## ----load-kirc----------------------------------------------------------------
data("kircIMR", package = "IntegMultiReg")
sapply(kircIMR$platforms, dim)
kircIMR$model_subgroup_sizes

## ----kirc-fit, eval = FALSE---------------------------------------------------
# kirc_fit <- imr(
#   x = kircIMR$platforms,
#   outcome            = kircIMR$outcome.survival,
#   covariates = kircIMR$covariates,
#   outcome_type       = "right.censored",
#   nu                 = c(-4, -3, -4),
#   draws = 4000, burnin = 1000,
#   min_subgroup_size              = 30,
#   seed               = 1
# )
# summary(kirc_fit)
# plot_top_features(kirc_fit, top = 12)

## ----fit----------------------------------------------------------------------
fit <- imr(
  x = simIMR$platforms,
  outcome            = simIMR$outcome.binary,
  covariates = simIMR$covariates,
  outcome_type       = "binary",
  nu                 = c(-4, -3, -4),
  draws = 1500, burnin = 500,
  min_subgroup_size              = 30,
  seed               = 1
)
fit

## ----plot-sizes, fig.height = 3.6---------------------------------------------
plot_subgroup_sizes(fit)

## ----summary------------------------------------------------------------------
summary(fit, threshold = 0.5)

## ----plot-selection-----------------------------------------------------------
plot(fit, type = "selection", platform = 1)

## ----plot-top, fig.height = 4-------------------------------------------------
plot_top_features(fit, top = 8)

## ----plot-trace---------------------------------------------------------------
plot(fit, type = "trace")

## ----predict------------------------------------------------------------------
new_x <- simIMR$platforms$genomic[1:20, ]
new_p <- simIMR$platforms$proteomic[1:20, ]
pred <- predict(fit, newdata = list(new_x, new_p),
                covariates = simIMR$covariates)
head(pred[["model:011"]])

## ----cv-----------------------------------------------------------------------
cv <- cv_imr(fit, k = 5, rounds = 3, cv_method = "refit")
cv$metric
round(colMeans(cv$pooled), 3)

## ----other-types, eval = FALSE------------------------------------------------
# # continuous (Gaussian) outcome
# fit_c <- imr(
#   simIMR$platforms, simIMR$outcome.continuous, covariates = simIMR$covariates,
#   outcome_type = "continuous", nu = c(-4, -3, -4),
#   draws = 1500, burnin = 500, min_subgroup_size = 30, seed = 1)
# 
# # right-censored survival outcome
# fit_s <- imr(
#   simIMR$platforms, simIMR$outcome.survival, covariates = simIMR$covariates,
#   outcome_type = "right.censored", nu = c(-4, -3, -4),
#   draws = 1500, burnin = 500, min_subgroup_size = 30, seed = 1)

